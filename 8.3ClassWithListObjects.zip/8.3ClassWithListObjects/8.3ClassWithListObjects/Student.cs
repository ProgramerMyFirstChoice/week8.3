﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace _8._3ClassWithListObjects
{
    public class Student
    {
        // Fields
        private string _fName;
        private string _lName;
        private List<double> _csharpGradeList = new List<double>();
        private List<double> _digitalGradeList = new List<double>();
        private List<double> _dataBaseGradeList = new List<double>();

        // Default Constructor
        public Student() { }

        // proterties
        public string FirstName { get { return _fName; } set { _fName = value; } }
        public string LastName { get { return _lName; } set { _lName = value; } }

        // List properties
        public List<double> CsharpGradeList{ get { return _csharpGradeList; } set { _csharpGradeList = value; } }
        public List<double> DigitalGradeList { get { return _digitalGradeList; } set { _digitalGradeList = value; } }
        public List<double> DataBaseGradeList { get { return _dataBaseGradeList; } set { _dataBaseGradeList = value; } }



        // Method to calculat the grade point average
        public double AverageGrade(List<double> gradeList)
        {
            double total = 0;
            foreach (double grade in gradeList)
            {
                total += grade;
            }

            return total / gradeList.Count;
        }
        
        // create the random object in class level not the method 
        // to create different random or same random number
        Random rand = new Random();

        // method to create elemets of the list class
        public List<double> CreateRandomGradeList(List<double> gradeList)
        {
           
            double grade = 0;
            for (int i = 0; gradeList.Count < 5; i++)
            {
                grade = rand.Next(10, 25) + rand.Next(10, 25) + rand.Next(10, 25) + rand.Next(10, 25);
                gradeList.Add(grade);
            }

            return gradeList;
        }

    }

}
