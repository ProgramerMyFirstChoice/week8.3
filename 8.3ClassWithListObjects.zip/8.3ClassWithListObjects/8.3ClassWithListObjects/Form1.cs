﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace _8._3ClassWithListObjects
{
    /* Nahom Gebreyohannies
     * 
     * Course CSI 154
     * 8.3 Class With a List of Objects
     * Instructor Christy Hernadaze
     */

    public partial class Form1 : Form
    {
        // Array of student names
        string[] fName = new string[] { "Abe", "Brad", "Cris", "Don", "Ed" };
        string[] lName = new string[] { "Agile", "Boen", "Carp", "Dela", "Estado" };

        // Creat an object for each student
        Student abe = new Student();
        Student brad = new Student();
        Student cris = new Student();
        Student don = new Student();
        Student ed = new Student();

        // List to collect student name and grades
        List<Student> studentList = new List<Student>();
        

        public Form1()
        {
            InitializeComponent();
        }

        // Method display name and display grades and grades average of each student
        private void DisplayLists(List<Student> listOfStudent)
        {

            foreach (Student s in listOfStudent)
            {
                // Display the first name and last name of the student
                richTextBox1.Text += s.FirstName + "  " + s.LastName + 
                    " lists of grade and grade point average(GPA)\n";

                // Display grade list and calculating average of CSharp
                richTextBox1.Text += "C# grades:\n";
                foreach (double grade in s.CsharpGradeList)
                {
                    richTextBox1.Text += grade + "\n";

                }
                double averageCSharp = s.AverageGrade(s.CsharpGradeList);

                richTextBox1.Text += "Average of CSharp grade: " + 
                    averageCSharp.ToString("f2") + "\n";

                // Display grade list and calculating average of Digital Imaging
                richTextBox1.Text += "\nDigital Imaging Grade:\n";
                foreach (double grade in s.DigitalGradeList)
                {
                    richTextBox1.Text += grade + "\n";

                }
               double averageDigitalGrade = s.AverageGrade(s.DigitalGradeList);

                richTextBox1.Text += "Average of Digital Imaging grade: " +
                    averageDigitalGrade.ToString("f2") + "\n";

                // Display grade list and calculating average of database
                richTextBox1.Text += "\nDatabase Grades:\n";
                foreach (double grade in s.DataBaseGradeList)
                {
                    richTextBox1.Text += grade + "\n";

                }
                double averageDatabaseGrade = s.AverageGrade(s.DataBaseGradeList);


                richTextBox1.Text += "Average of Database grades: " + 
                    averageDatabaseGrade.ToString("f2") + "\n";

                
                // Calculate the combined avearge of three course
                double averageThreeCourse = CombinedAverage(averageCSharp, averageDatabaseGrade, averageDigitalGrade);
                richTextBox1.Text += "\n\nCombine Average of the three course: " +
                    averageThreeCourse.ToString("f2") + "\n";

                richTextBox1.Text += "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n";
                richTextBox1.Text += "\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n\n";

                
            }
        }
        
        private void btnDisplay_Click(object sender, EventArgs e)
        {
            // Clear the richTextBox1
            richTextBox1.Clear();

            // Clear the list to display the result one time in richtextbox1
            studentList.Clear();

            // Add student name and create grades list  for Abe to student list 
            abe.CsharpGradeList = abe.CreateRandomGradeList(abe.CsharpGradeList);
            abe.DigitalGradeList = abe.CreateRandomGradeList(abe.DigitalGradeList);
            abe.DataBaseGradeList = abe.CreateRandomGradeList(abe.DataBaseGradeList);
            abe.FirstName = fName[0];
            abe.LastName = lName[4];
            studentList.Add(abe);

            // Add student name and create grades list  for Brad to student list
            brad.CsharpGradeList = brad.CreateRandomGradeList(brad.CsharpGradeList);
            brad.DigitalGradeList = brad.CreateRandomGradeList(brad.DigitalGradeList);
            brad.DataBaseGradeList = brad.CreateRandomGradeList(brad.DataBaseGradeList);
            brad.FirstName = fName[1];
            brad.LastName = lName[3];
            studentList.Add(brad);

            // Add student name and create grades list  for Cris to student list
            cris.CsharpGradeList = cris.CreateRandomGradeList(cris.CsharpGradeList);
            cris.DigitalGradeList = cris.CreateRandomGradeList(cris.DigitalGradeList);
            cris.DataBaseGradeList = cris.CreateRandomGradeList(cris.DataBaseGradeList);
            cris.FirstName = fName[2];
            cris.LastName = lName[2];
            studentList.Add(cris);

            // Add student name and create grades list  for Don to student list
            don.CsharpGradeList = don.CreateRandomGradeList(don.CsharpGradeList);
            don.DigitalGradeList = don.CreateRandomGradeList(don.DigitalGradeList);
            don.DataBaseGradeList = don.CreateRandomGradeList(don.DataBaseGradeList);
            don.FirstName = fName[3];
            don.LastName = lName[1];
            studentList.Add(don);

            // Add student name and create grades list  for Ed to student list
            ed.CsharpGradeList = ed.CreateRandomGradeList(ed.CsharpGradeList);
            ed.DigitalGradeList = ed.CreateRandomGradeList(ed.DigitalGradeList);
            ed.DataBaseGradeList = ed.CreateRandomGradeList(ed.DataBaseGradeList);
            ed.FirstName = fName[4];
            ed.LastName = lName[0];
            studentList.Add(ed);
            
            // Display the lists of student name, grades , and grade average
            // richTextBox1
            DisplayLists(studentList);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // Clear the richTextBox1
            richTextBox1.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        // Method calculating avearge of the three course
        private double CombinedAverage(double avcSharp, double avdata, double avdigital )
        {
            double combineAverage = 0;

            combineAverage = avcSharp + avdata + avdigital;

            return combineAverage;
        }
    }

}
